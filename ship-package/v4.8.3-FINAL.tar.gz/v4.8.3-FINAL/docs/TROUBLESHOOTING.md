# SHARK AGENT v4.8.3 — TROUBLESHOOTING GUIDE

Common issues and their solutions for Shark Agent v4.8.3.

---

## 🔍 DIAGNOSTIC COMMANDS

Run these first when troubleshooting:

```bash
# 1. Check build status
cd ~/.config/opencode/plugins/shark-agent-v4.8.3
npm run build

# 2. Run test suite
bash tests/container/test-suite.sh

# 3. Check bundle
ls -lh dist/index.js

# 4. Check evidence
ls -la .shark/evidence/
```

---

## 🐛 COMMON ISSUES

### Issue 1: Plugin Fails to Load

**Symptoms:**
```
Error: Cannot find module '@opencode-ai/plugin'
Plugin failed to load: silent failure
```

**Diagnosis:**
```bash
# Check if peer dependency is installed
ls node_modules/@opencode-ai/

# Check if dist/index.js exists
ls -la dist/
```

**Solutions:**

**Solution A:** Install peer dependencies
```bash
npm install
npm run build
```

**Solution B:** Link OpenCode's plugin package
```bash
cd node_modules/@opencode-ai
ln -sf /path/to/opencode/node_modules/@opencode-ai/plugin plugin
```

**Solution C:** Check OpenCode version
```bash
opencode --version
# Should be >= 1.4.3
```

---

### Issue 2: shark-status Shows `brain: "unknown"`

**Symptoms:**
```
shark-status returns:
{
  "brain": "unknown",
  ...
}
```

**Diagnosis:**
This is **normal on first run**. Brain initializes on first `chat.message` hook.

**Solutions:**

**Solution A:** Wait for brain initialization
- Send any message in OpenCode TUI
- Run `shark-status` again

**Solution B:** Check session-hook.ts fires
```bash
# In TUI, run:
/logs

# Look for session hook firing
```

**Solution C:** Verify agent identity function
```bash
grep "isSharkAgent" dist/index.js | head -3
```

---

### Issue 3: Container Tests Failing

**Symptoms:**
```
Tests Run:    9
Tests Passed: X
Tests Failed: Y
```

**Solutions:**

**Solution A:** Verify test file paths
```bash
# Check theatrical detector file exists
ls src/validation/theatrical-detector.ts

# Check brains.ts has MOCK ban
grep "MOCK" src/shark/macro/brains.ts
```

**Solution B:** Run tests in correct directory
```bash
cd ~/.config/opencode/plugins/shark-agent-v4.8.3
bash tests/container/test-suite.sh
```

**Solution C:** Check Docker image
```bash
# Verify opencode-test image exists
docker images | grep opencode-test

# Rebuild if needed
docker build -t opencode-test:1.4.3 /path/to/test/Dockerfile
```

---

### Issue 4: Gate Cannot Be Advanced

**Symptoms:**
```
shark-gate action=advance
# Returns but gate doesn't advance
```

**Diagnosis:**
```bash
# Check current gate status
shark-gate action=status

# Check evidence exists
ls .shark/evidence/*/
```

**Solutions:**

**Solution A:** Check evidence for current gate
```bash
# For example, if trying to advance from plan gate:
ls .shark/evidence/plan/

# Should contain evidence files
```

**Solution B:** Verify gate-enforce-hook is wired
```bash
grep "gate-enforce" dist/index.js | head -3
```

**Solution C:** Check blocking criteria
```bash
shark-gate action=criteria gate=plan
```

---

### Issue 5: TypeScript Errors with Zod

**Symptoms:**
```
ERROR: Type 'ZodEnum<{ run: "run"; ...}>' is not assignable to type '$ZodType'
```

**Diagnosis:**
This is a **cosmetic issue only**. The build passes.

**Solutions:**

**Solution A:** Ignore - build works
```bash
npm run build
# Build succeeds despite type errors
```

**Solution B:** Check zod version mismatch
```bash
grep "zod" package.json
# Shows: "zod": "^4.1.8"
# But OpenCode uses zod@^3.x
```

**Solution C:** Suppress with tsconfig
```bash
# Add to tsconfig.json:
{
  "compilerOptions": {
    "skipLibCheck": true
  }
}
```

---

### Issue 6: Hooks Not Firing

**Symptoms:**
```
Guardian patterns not blocking
Gate hooks not collecting evidence
```

**Diagnosis:**
```bash
# Check hooks are exported
grep "createSharkHooks" dist/index.js

# Check hook implementations
grep "Hooks\[" dist/index.js | head -10
```

**Solutions:**

**Solution A:** Verify opencode run vs TUI
```bash
# Hooks fire properly in TUI mode
opencode  # TUI mode

# Hooks may NOT fire in opencode run mode
opencode run "message"  # May bypass hooks
```

**Solution B:** Check agent identity
```bash
# All hooks check isSharkAgent
grep "isSharkAgent" dist/index.js | wc -l
# Should show ~20+ occurrences
```

**Solution C:** Verify hook wiring in index.ts
```bash
# Check src/hooks/v4.1/index.ts
cat src/hooks/v4.1/index.ts
```

---

### Issue 7: Bundle Size Changed Unexpectedly

**Symptoms:**
```
# Bundle is larger or smaller than expected
du -sh dist/index.js
# Expected: ~0.62 MB
```

**Diagnosis:**
```bash
# Check git history for bundle changes
git log --oneline --all dist/index.js

# Compare with previous commit
git diff 5bf38fa..ad4641e -- dist/index.js | head -20
```

**Solutions:**

**Solution A:** Rebuild clean
```bash
rm -rf dist/
npm run build
```

**Solution B:** Check for circular deps
```bash
npm run build 2>&1 | grep -i "circular\|cycle"
```

---

### Issue 8: Permission Denied Errors

**Symptoms:**
```
Error: EACCES: permission denied
```

**Diagnosis:**
```bash
# Check file ownership
ls -la ~/.config/opencode/

# Check directory permissions
ls -ld ~/.config/opencode/plugins
```

**Solutions:**

**Solution A:** Fix ownership
```bash
sudo chown -R $(whoami) ~/.config/opencode/
```

**Solution B:** Fix permissions
```bash
chmod 755 ~/.config/opencode/
chmod -R 755 ~/.config/opencode/plugins/
```

---

### Issue 9: Docker Container Test Errors

**Symptoms:**
```
docker: Error response from daemon...
docker: invalid reference format...
```

**Diagnosis:**
```bash
# Check Docker is running
docker ps

# Check image exists
docker images | grep opencode-test
```

**Solutions:**

**Solution A:** Start Docker
```bash
sudo systemctl start docker
dockerd &
```

**Solution B:** Fix image reference
```bash
# Use full image name
docker pull opencode-test:1.4.3

# Or rebuild
docker build -t opencode-test:1.4.3 .
```

**Solution C:** Check volume mounts
```bash
# Verify paths are correct
ls /tmp/shark-tui-test-*/config/

# Fix working directory
cd /correct/path && docker run ...
```

---

### Issue 10: Evidence Not Being Collected

**Symptoms:**
```
# .shark/evidence/ directories are empty
ls .shark/evidence/plan/
ls .shark/evidence/build/
```

**Diagnosis:**
```bash
# Check evidence collector is instantiated
grep "EvidenceCollector" dist/index.js

# Check evidence directory path
grep "EVIDENCE_DIR" dist/index.js
```

**Solutions:**

**Solution A:** Verify permissions
```bash
chmod 755 .shark/
chmod 755 .shark/evidence/
```

**Solution B:** Check base path
```bash
# EvidenceCollector takes basePath constructor arg
grep "new EvidenceCollector" src/
```

**Solution C:** Run gate operations to collect evidence
```bash
# Gate evidence only collects on gate operations
shark-gate action=evaluate gate=plan passed=true
ls .shark/evidence/plan/
```

---

## 🚨 ESCALATION PROCEDURES

If basic troubleshooting doesn't resolve:

### Step 1: Capture State

```bash
# Create troubleshooting bundle
mkdir -p /tmp/shark-debug
cp -r ~/.config/opencode/plugins/shark-agent-v4.8.3/ship-package/v4.8.3-FINAL/* /tmp/shark-debug/

# Capture logs
opencode > /tmp/shark-debug/opencode.log 2>&1 &
sleep 30
kill %1

# Capture config
cp ~/.config/opencode/opencode.json /tmp/shark-debug/
```

### Step 2: Verify Manifest

```bash
cd ~/.config/opencode/plugins/shark-agent-v4.8.3
sha256sum dist/index.js src/hooks/v4.1/index.ts src/shared/gates.ts > /tmp/shark-debug/manifest.sha256
# Compare with MANIFEST.md
```

### Step 3: Check Git Status

```bash
cd ~/.config/opencode/plugins/shark-agent-v4.8.3
git status
git log --oneline -5
git diff HEAD
```

---

## 📋 TROUBLESHOOTING CHECKLIST

Use this checklist for systematic debugging:

```bash
#!/bin/bash
# Shark Agent Troubleshooting Checklist

echo "=== SHARK AGENT v4.8.3 TROUBLESHOOTING ==="
echo ""

echo "1. Build Check"
npm run build 2>&1 | tail -3
echo ""

echo "2. Bundle Size"
du -sh dist/index.js
echo ""

echo "3. Test Suite"
bash tests/container/test-suite.sh 2>&1 | tail -5
echo ""

echo "4. Evidence Directories"
ls -la .shark/evidence/
echo ""

echo "5. Hook Count"
grep -c "Hook" dist/index.js
echo ""

echo "6. Gate Enforce Hook"
grep -c "gate-enforce-hook" dist/index.js
echo ""

echo "7. Git Status"
git log --oneline -3
echo ""

echo "=== CHECK COMPLETE ==="
```

---

## 🔗 REFERENCE DOCUMENTATION

| Document | Topic |
|----------|-------|
| [README.md](./README.md) | Package overview |
| [INSTALLATION.md](./INSTALLATION.md) | Installation guide |
| [MANIFEST.md](./MANIFEST.md) | File integrity |
| [CHECKPOINTS.md](./CHECKPOINTS.md) | Version history |
| [FIREWALL_AUDIT.md](./FIREWALL_AUDIT.md) | Guardian analysis |
| [evidence/audit/](./evidence/audit/) | SAST/secrets |

---

## 📞 SUPPORT REQUESTS

When requesting support, include:

1. **Output of diagnostic commands**
2. **opencode.json configuration**
3. **Error messages (full, not truncated)**
4. **Git commit hash:** `git log -1 --format='%H'`
5. **OpenCode version:** `opencode --version`
6. **Operating system and Docker version**

---

**🔧 END OF TROUBLESHOOTING.md**