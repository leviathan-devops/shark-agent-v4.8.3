# SHARK AGENT v4.8.3 — INSTALLATION GUIDE

Complete step-by-step instructions for installing Shark Agent v4.8.3.

---

## 📋 PREREQUISITES

### System Requirements

| Requirement | Version | Notes |
|-------------|---------|-------|
| Node.js | >= 18.0.0 | Required for plugin |
| npm | >= 9.0.0 | For package management |
| OpenCode | 1.4.3+ | Plugin host |
| Docker | Latest | For container testing |
| bun | Latest | For building (optional, npm works too) |

### Required Access

- Write access to `~/.config/opencode/` directory
- sudo/root access for Docker (if using container tests)

---

## 📥 INSTALLATION METHODS

### Method 1: Fresh Install (Recommended)

```bash
# 1. Create plugin directory
mkdir -p ~/.config/opencode/plugins/shark-agent-v4.8.3

# 2. Copy package contents
cp -r /path/to/ship-package/v4.8.3-FINAL/* ~/.config/opencode/plugins/shark-agent-v4.8.3/

# 3. Navigate to plugin directory
cd ~/.config/opencode/plugins/shark-agent-v4.8.3

# 4. Install dependencies
npm install

# 5. Build the plugin
npm run build

# 6. Verify build output
ls -la dist/
# Should show: index.js (0.62 MB)
```

### Method 2: Git Clone

```bash
# 1. Clone the repository
git clone https://github.com/leviathan-devops/shark-agent-v4.8.3.git shark-agent-v4.8.3
cd shark-agent-v4.8.3

# 2. Checkout ship-ready commit
git checkout ad4641e

# 3. Install dependencies
npm install

# 4. Build
npm run build
```

### Method 3: From Existing Installation

```bash
# 1. Navigate to existing shark-agent directory
cd ~/.config/opencode/plugins/shark-agent-v4.8.3

# 2. Pull latest
git fetch origin
git checkout v4.8.3
git pull origin v4.8.3

# 3. Rebuild
npm run build
```

---

## ⚙️ OPENCODE CONFIGURATION

### Step 1: Update opencode.json

Add Shark Agent to your OpenCode plugin configuration:

```bash
# Get current config
cat ~/.config/opencode/opencode.json

# If empty or missing, create it:
cat > ~/.config/opencode/opencode.json << 'EOF'
{
  "$schema": "https://opencode.ai/config.json",
  "provider": {
    "minimax": {}
  },
  "plugin": [
    "file:///root/.config/opencode/plugins/shark-agent-v4.8.3/dist/index.js"
  ]
}
EOF
```

### Step 2: Verify Plugin Loads

```bash
# Start OpenCode TUI
opencode

# In the session, run:
shark-status

# Expected output:
# {
#   "brain": "shark",
#   "currentGate": "plan",
#   "iteration": "V1.0",
#   "gateStatuses": {
#     "plan": "pending",
#     ...
#   }
# }
```

### Step 3: Check Agent Identity

```bash
# Run:
shark-status

# Should show "brain": "shark"
# If shows "brain": "unknown", brain not initialized yet
```

---

## ✅ VERIFICATION CHECKLIST

Run through this checklist to verify a successful installation:

### Build Verification

```bash
cd ~/.config/opencode/plugins/shark-agent-v4.8.3

# Check bundle exists and size
ls -lh dist/index.js
# Expected: ~0.62 MB

# Run TypeScript check (will show zod type errors - ignore these)
npm run typecheck 2>&1 | head -20
# Build passes despite type errors
```

### Test Suite Verification

```bash
cd ~/.config/opencode/plugins/shark-agent-v4.8.3

# Run container test suite
bash tests/container/test-suite.sh

# Expected: ALL TESTS PASSED (9/9)
```

### Hook Wiring Verification

```bash
# Check that hooks are exported
grep -l "createSharkHooks" dist/index.js

# Check gate-enforce-hook is present
grep "gate-enforce-hook" dist/index.js | head -1
```

### Evidence Verification

```bash
cd ~/.config/opencode/plugins/shark-agent-v4.8.3

# Check audit evidence exists
ls -la .shark/evidence/audit/

# Should show:
# - AuditReport.json
# - SASTReport.json
# - SecretsScan.json
```

---

## 🐳 CONTAINER TESTING SETUP

Container testing is **MANDATORY** for the delivery gate.

### Prerequisites

```bash
# Check Docker is available
docker --version

# Check opencode-test image exists
docker images | grep opencode-test
# If not, build it first (see TROUBLESHOOTING.md)
```

### Running Container Tests

```bash
cd ~/.config/opencode/plugins/shark-agent-v4.8.3

# Create test directory
TEST_DIR="/tmp/shark-tui-test-$(date +%s)"
mkdir -p "$TEST_DIR/config/plugins/shark-agent-v4.8.3"

# Copy built plugin
cp dist/index.js "$TEST_DIR/config/plugins/shark-agent-v4.8.3/"

# Create config
cat > "$TEST_DIR/config/opencode.json" << 'EOF'
{
  "$schema": "https://opencode.ai/config.json",
  "provider": { "minimax": {} },
  "plugin": ["file:///root/.config/opencode/plugins/shark-agent-v4.8.3/dist/index.js"]
}
EOF

# Run container test
docker run -it --rm \
  -v "$TEST_DIR/config:/root/.config/opencode" \
  opencode-test:1.4.3

# Inside container, run:
shark-test-runner action=run
```

### Manual Container Testing

```bash
# Start interactive container
docker run -it --rm \
  -v "$TEST_DIR/config:/root/.config/opencode" \
  opencode-test:1.4.3 bash

# Inside container:
opencode
# Then run shark-status, shark-gate, etc.
```

---

## 🔧 POST-INSTALLATION CONFIGURATION

### Agent Identity

Shark Agent auto-detects its identity via `isSharkAgent()` function. The agent will be identified as "shark" once the `chat.message` hook fires with an agent field.

### Gate Initialization

On first run, all gates start as `pending`:

```
plan: pending
build: pending
test: pending
verify: pending
audit: pending
delivery: pending
```

### Customizing Guardian Patterns

Edit `src/hooks/v4.1/guardian-hook.ts` to customize L0-L8 patterns:

```bash
# Edit guardian-hook.ts
nano src/hooks/v4.1/guardian-hook.ts

# Rebuild after changes
npm run build
```

### Customizing Gate Criteria

Edit `src/shared/gates.ts` to customize gate criteria:

```bash
# Edit gates.ts
nano src/shared/gates.ts

# Rebuild after changes
npm run build
```

---

## 🚀 UPGRADING

### From v4.8.2 or earlier

```bash
cd ~/.config/opencode/plugins/shark-agent-v4.8.3

# Backup current installation
cp -r dist dist.backup

# Pull latest
git fetch origin
git checkout v4.8.3
git pull origin v4.8.3

# Rebuild
npm run build

# Verify
bash tests/container/test-suite.sh
```

### From v4.7

```bash
# v4.8.x has significant changes from v4.7
# Full reinstall recommended

# 1. Remove old installation
rm -rf ~/.config/opencode/plugins/shark-agent-v4.8.3

# 2. Follow fresh install instructions above
```

---

## 📦 UNINSTALLATION

```bash
# 1. Remove plugin directory
rm -rf ~/.config/opencode/plugins/shark-agent-v4.8.3

# 2. Remove from opencode.json
# Edit ~/.config/opencode/opencode.json and remove the plugin entry

# 3. Restart OpenCode
opencode
```

---

## 🔍 VERIFICATION COMMANDS

Use these commands to verify installation:

```bash
# Full verification
cd ~/.config/opencode/plugins/shark-agent-v4.8.3

# 1. Build check
npm run build 2>&1 | tail -5

# 2. Test suite
bash tests/container/test-suite.sh 2>&1 | tail -10

# 3. Type check (ignore zod errors)
npm run typecheck 2>&1 | grep -v "zod" | head -10

# 4. Bundle size
du -sh dist/index.js

# 5. Hook count
grep -c "create.*Hook" dist/index.js

# 6. Gate enforce present
grep -c "gate-enforce-hook" dist/index.js
```

---

## ⚠️ KNOWN ISSUES

### Zod Type Mismatch

**Issue:** TypeScript shows errors like `Type 'ZodEnum' is not assignable to type '$ZodType'`

**Cause:** Plugin uses `zod@^4.1.8` but OpenCode uses `zod@^3.x`

**Impact:** None - build passes, plugin works correctly

**Fix:** None needed - cosmetic only

### Brain Initialization

**Issue:** `shark-status` shows `brain: "unknown"` on first run

**Cause:** Brain initializes on first `chat.message` hook

**Fix:** Normal behavior - brain will show "shark" after first message

### Host Testing vs Container Testing

**Issue:** Tests pass on host but fail in container

**Cause:** Some patterns behave differently in container environment

**Fix:** Always run full container test suite before shipping

---

## 📞 GETTING HELP

1. **Check troubleshooting:** See [TROUBLESHOOTING.md](TROUBLESHOOTING.md)
2. **Run diagnostics:** `bash tests/container/test-suite.sh`
3. **Check evidence:** Review `.shark/evidence/` directory
4. **Verify manifest:** See [MANIFEST.md](MANIFEST.md)

---

**🔗 END OF INSTALLATION.md**