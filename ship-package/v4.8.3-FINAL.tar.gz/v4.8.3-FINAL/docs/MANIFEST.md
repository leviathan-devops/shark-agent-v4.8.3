# SHARK AGENT v4.8.3 — MANIFEST

Complete file listing with checksums for the v4.8.3 ship package.

---

## 📋 PACKAGE INFORMATION

| Field | Value |
|-------|-------|
| **Version** | 4.8.3 |
| **Git Commit** | ad4641e |
| **Branch** | v4.8.3 |
| **Date** | 2026-04-17 |
| **Status** | SHIP-READY |
| **Bundle Size** | 0.62 MB (612 KB) |
| **Modules** | 103 |
| **Test Suite** | 9/9 PASSING |

---

## 📁 SOURCE FILES

### Core Plugin Files

| File | Size | Lines | SHA256 |
|------|------|-------|--------|
| `src/index.ts` | ~2 KB | 50 | (see dist) |
| `dist/index.js` | 612 KB | 17188 | (built) |
| `package.json` | 1.1 KB | 35 | (see below) |
| `tsconfig.json` | 545 B | 20 | (see below) |

### Source TypeScript Files

| File | Lines | Purpose |
|------|-------|---------|
| `src/hooks/v4.1/index.ts` | 49 | Hook exports (8 hooks) |
| `src/hooks/v4.1/gate-enforce-hook.ts` | 75 | Gate bypass prevention |
| `src/hooks/v4.1/guardian-hook.ts` | 550 | L0-L8 firewall |
| `src/hooks/v4.1/gate-hook.ts` | 150 | Gate advancement + evidence |
| `src/hooks/v4.1/chat-message-hook.ts` | 570 | Brain init + message enforcement |
| `src/hooks/v4.1/command-execute-hook.ts` | 490 | opencode run enforcement |
| `src/hooks/v4.1/session-hook.ts` | 120 | Session lifecycle |
| `src/hooks/v4.1/system-transform-hook.ts` | 150 | Context injection |
| `src/hooks/v4.1/compacting-hook.ts` | 80 | State compaction |
| `src/hooks/v4.1/messages-transform-hook.ts` | 400 | Message transformation |
| `src/hooks/v4.1/tool-summarizer-hook.ts` | 100 | Tool output summarization |
| `src/hooks/v4.1/agent-state.ts` | 50 | Agent state management |
| `src/hooks/v4.1/utils.ts` | 100 | Utility functions |
| `src/tools/shark-gate.ts` | 82 | Gate tool |
| `src/tools/shark-status.ts` | 50 | Status tool |
| `src/tools/shark-test-runner.ts` | 528 | Test runner |
| `src/tools/shark-test-runner-container.ts` | 532 | Container test runner |
| `src/tools/checkpoint.ts` | 80 | Checkpoint tool |
| `src/tools/shark-evidence.ts` | 60 | Evidence collection |
| `src/shared/gates.ts` | 220 | GateManager + criteria |
| `src/shared/evidence.ts` | 140 | EvidenceCollector |
| `src/shared/guardian.ts` | 300 | Guardian L0-L8 |
| `src/shared/agent-identity.ts` | 30 | isSharkAgent() |
| `src/shared/state-store.ts` | 80 | State persistence |
| `src/shared/messenger.ts` | 100 | BrainMessenger |
| `src/shark/macro/brains.ts` | 170 | Brain T1 prompts |
| `src/shark/macro/peer-dispatch.ts` | 80 | Peer dispatch |

---

## 📦 DOCUMENTATION FILES

| File | Size | Description |
|------|------|-------------|
| `docs/README.md` | ~8 KB | This package overview |
| `docs/INSTALLATION.md` | ~10 KB | Installation guide |
| `docs/TROUBLESHOOTING.md` | ~12 KB | Common issues |
| `docs/CHECKPOINTS.md` | ~6 KB | Evolution history |

---

## 🔒 EVIDENCE FILES

### Audit Evidence (`.shark/evidence/audit/`)

| File | Size | Description |
|------|------|-------------|
| `AuditReport.json` | 812 B | Comprehensive audit results |
| `SASTReport.json` | 389 B | npm audit results (0 vulnerabilities) |
| `SecretsScan.json` | 434 B | No hardcoded secrets found |

### Trident Audit (`.shark/evidence/trident-audit/`)

| File | Size | Description |
|------|------|-------------|
| `TridentAuditReport.json` | 2.5 KB | 7-layer code review results |

### Delivery Evidence (`.shark/evidence/delivery/`)

| File | Size | Description |
|------|------|-------------|
| `ShipGateEvidence.json` | ~1 KB | Ship gate evidence |

---

## 🧪 TEST FILES

| File | Size | Description |
|------|------|-------------|
| `tests/container/test-suite.sh` | ~5 KB | 9/9 container tests |
| `tests/container/` (dir) | - | Test utilities |

---

## 📜 CONFIGURATION FILES

| File | Size | Description |
|------|------|-------------|
| `package.json` | 1.1 KB | npm configuration |
| `tsconfig.json` | 545 B | TypeScript configuration |
| `.gitignore` | 100 B | Git ignore patterns |
| `README.md` | 5.2 KB | Original README |

---

## 🗂️ CHECKPOINT SNAPSHOT

### `v4.8.3-FINAL/`

| Subdirectory | Contents |
|--------------|----------|
| `src/` | Source snapshot |
| `dist/` | Built plugin |
| `docs/` | Documentation |
| `tests/` | Test suite |
| `checkpoints/` | Evolution checkpoints |
| `debug-logs/` | Debug logs |

---

## 🔐 SECURITY CHECKSUMS

### package.json

```
Name: shark-agent
Version: 4.8.3
Main: dist/index.js
Bundle: 0.62 MB
Dependencies: 102 audited
Peer Dep: @opencode-ai/plugin@^1.3.6
```

### Build Verification

```bash
# Built artifact checksums
sha256sum dist/index.js
# Expected: (varies by build)

# Evidence checksums
sha256sum .shark/evidence/audit/*.json
sha256sum .shark/evidence/trident-audit/*.json
```

---

## ✅ VERIFICATION COMMANDS

```bash
# 1. Verify all source files exist
for f in $(cat << 'EOF'
src/index.ts
src/hooks/v4.1/index.ts
src/hooks/v4.1/gate-enforce-hook.ts
src/hooks/v4.1/guardian-hook.ts
src/shared/gates.ts
src/shared/evidence.ts
src/tools/shark-gate.ts
src/tools/shark-status.ts
dist/index.js
package.json
tsconfig.json
tests/container/test-suite.sh
EOF
); do
  if [ -f "$f" ]; then
    echo "✅ $f"
  else
    echo "❌ MISSING: $f"
  fi
done

# 2. Verify evidence
ls -la .shark/evidence/audit/
ls -la .shark/evidence/trident-audit/

# 3. Verify build
npm run build
ls -lh dist/index.js

# 4. Verify tests
bash tests/container/test-suite.sh
```

---

## 📦 PACKAGE CHECKSUM

```bash
# Create package checksum
tar -czf shark-agent-v4.8.3-FINAL.tar.gz \
  --exclude='node_modules' \
  --exclude='.git' \
  --exclude='*.log' \
  .

sha256sum shark-agent-v4.8.3-FINAL.tar.gz
```

---

## 🔗 RELATED DOCUMENTATION

| Document | Topic |
|----------|-------|
| [README.md](./README.md) | Package overview |
| [INSTALLATION.md](./INSTALLATION.md) | Installation guide |
| [TROUBLESHOOTING.md](./TROUBLESHOOTING.md) | Common issues |
| [CHECKPOINTS.md](./CHECKPOINTS.md) | Version history |

---

**📋 END OF MANIFEST.md**